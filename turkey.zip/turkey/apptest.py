import re
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st


# =========================================================
# Конфигурация
# =========================================================
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "best_model_pipeline.pkl"
SCHEMA_PATH = BASE_DIR / "feature_schema.pkl"
DATA_PATH = BASE_DIR / "real_estate_data.csv"

st.set_page_config(
    page_title="Прогноз стоимости недвижимости",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="expanded",
)

TEST_MAE_LOG = 0.2813


# =========================================================
# Загрузка артефактов
# =========================================================
@st.cache_resource
def load_model():
    if MODEL_PATH.exists():
        return joblib.load(MODEL_PATH)
    return None


@st.cache_resource
def load_schema():
    if SCHEMA_PATH.exists():
        return joblib.load(SCHEMA_PATH)
    return None


@st.cache_data
def load_dataset():
    if DATA_PATH.exists():
        return pd.read_csv(DATA_PATH, low_memory=False)
    return None


model = load_model()
schema = load_schema()
df = load_dataset()

MODEL_NAME = "RandomForest"
if schema is not None:
    MODEL_NAME = schema.get("model_name", "RandomForest")

MODEL_FEATURES = [
    "type", "sub_type", "listing_type", "building_age", "total_floor_count",
    "floor_no", "room_count", "size", "heating_type", "city", "district",
    "neighborhood", "rooms_numeric", "is_new_building", "floor_ratio",
    "room_grouped", "city_grouped",
]
NUMERIC_FEATURES = [
    "listing_type", "building_age", "total_floor_count", "floor_no", "size",
    "rooms_numeric", "is_new_building", "floor_ratio",
]
CATEGORICAL_FEATURES = [
    "type", "sub_type", "room_count", "heating_type", "city", "district",
    "neighborhood", "room_grouped", "city_grouped",
]

if schema is not None:
    MODEL_FEATURES = schema.get("all_features", MODEL_FEATURES)
    NUMERIC_FEATURES = schema.get("numeric_features", NUMERIC_FEATURES)
    CATEGORICAL_FEATURES = schema.get("categorical_features", CATEGORICAL_FEATURES)


# =========================================================
# Маппинги RU -> TR
# =========================================================
SUBTYPE_MAP = {
    "Квартира": "Daire",
    "Вилла": "Villa",
    "Отдельный дом": "Müstakil Ev",
    "Резиденция": "Rezidans",
    "Дача": "Yazlık",
    "Целое здание": "Komple Bina",
    "Сборный дом": "Prefabrik Ev",
    "Фермерский дом": "Çiftlik Evi",
    "Особняк / Усадьба / Дом у воды": "Köşk / Konak / Yalı",
    "Квартира у воды": "Yalı Dairesi",
    "Кооператив": "Kooperatif",
    "Лофт": "Loft",
}

HEATING_MAP = {
    "Фанкойл": "Fancoil",
    "Нет": "Yok",
    "Электрическое": "Kombi (Elektrikli)",
    "Солярное отопление": "Güneş Enerjisi",
    "Центральное (газ)": "Kalorifer (Doğalgaz)",
    "Калорифер (уголь)": "Kalorifer (Kömür)",
}

CITY_MAP = {
    "Адана": "Adana",
    "Анкара": "Ankara",
    "Анталья": "Antalya",
    "Айдын": "Aydın",
    "Балыкесир": "Balıkesir",
    "Бурса": "Bursa",
    "Эскишехир": "Eskişehir",
    "Кайсери": "Kayseri",
    "Коджаэли": "Kocaeli",
    "Мерсин": "Mersin",
    "Мугла": "Muğla",
    "Сакарья": "Sakarya",
    "Самсун": "Samsun",
    "Стамбул": "İstanbul",
    "Измир": "İzmir",
}

LISTING_MAP = {"Аренда": 0, "Аренда на день": 1, "Продажа": 2}

AGE_MAP = {
    "0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5,
    "6-10 лет": 8,
    "11-15 лет": 13,
    "16-20 лет": 18,
    "21-25 лет": 23,
    "26-30 лет": 28,
    "31-35 лет": 33,
    "36-40 лет": 38,
    "40 и более": 40,
}

FLOOR_SPECIAL = {
    "Высокий первый этаж": 1,
    "Первый этаж": 1,
    "Цокольный этаж -1": -1,
    "Цокольный этаж -2": -2,
    "Последний этаж": 99,
    "Мансарда": 99,
    "Садовый этаж": 0,
    "Отдельный": 0,
}


# =========================================================
# Утилиты
# =========================================================
def parse_number(value, default=np.nan):
    if pd.isna(value):
        return default
    m = re.search(r"-?\d+(?:[.,]\d+)?", str(value))
    if not m:
        return default
    return float(m.group(0).replace(",", "."))


def parse_range_midpoint(value):
    nums = re.findall(r"\d+", str(value))
    if len(nums) >= 2:
        return (float(nums[0]) + float(nums[1])) / 2
    if len(nums) == 1:
        return float(nums[0])
    return np.nan


def parse_rooms(value):
    nums = re.findall(r"\d+", str(value))
    if nums:
        return sum(int(x) for x in nums)
    return np.nan


def convert_age(value):
    if value in AGE_MAP:
        return AGE_MAP[value]
    return parse_range_midpoint(value)


def convert_floor_count(value):
    if str(value) == "20 и более":
        return 20.0
    return parse_range_midpoint(value)


def convert_floor(value):
    if value in FLOOR_SPECIAL:
        return float(FLOOR_SPECIAL[value])
    return parse_number(value)


def make_input(
    city,
    district,
    neighborhood,
    listing_type,
    sub_type,
    room_count,
    heating_type,
    size,
    building_age,
    total_floor_count,
    floor_no,
):
    age = convert_age(building_age)
    total_floors = convert_floor_count(total_floor_count)
    floor = convert_floor(floor_no)
    rooms_numeric = parse_rooms(room_count)

    city_model = CITY_MAP.get(city, city)
    sub_type_model = SUBTYPE_MAP.get(sub_type, sub_type)
    heating_model = HEATING_MAP.get(heating_type, heating_type)

    if pd.notna(floor) and pd.notna(total_floors) and total_floors > 0:
        floor_ratio = floor / total_floors
    else:
        floor_ratio = np.nan

    if pd.notna(age) and age <= 5:
        is_new = 1.0
    else:
        is_new = 0.0

    row = {
        "type": "Konut",
        "sub_type": sub_type_model,
        "listing_type": LISTING_MAP.get(listing_type, 0),
        "building_age": age,
        "total_floor_count": total_floors,
        "floor_no": floor,
        "room_count": room_count,
        "size": float(size),
        "heating_type": heating_model,
        "city": city_model,
        "district": district,
        "neighborhood": neighborhood,
        "rooms_numeric": rooms_numeric,
        "is_new_building": is_new,
        "floor_ratio": floor_ratio,
        "room_grouped": room_count,
        "city_grouped": city_model,
    }
    return pd.DataFrame([row], columns=MODEL_FEATURES)


def predict_price(input_df):
    pred_log = float(model.predict(input_df)[0])
    price = max(float(np.expm1(pred_log)), 0.0)
    low = max(float(np.expm1(pred_log - TEST_MAE_LOG)), 0.0)
    high = max(float(np.expm1(pred_log + TEST_MAE_LOG)), 0.0)
    return price, low, high


# =========================================================
# Опции для формы
# =========================================================
CITY_TO_DISTRICTS = {}
DISTRICT_TO_NEIGHBORHOODS = {}

if df is not None:
    tmp_cd = df.dropna(subset=["city", "district"])
    for city_name, group in tmp_cd.groupby("city"):
        CITY_TO_DISTRICTS[str(city_name)] = sorted(
            set(str(x) for x in group["district"].unique())
        )

    tmp_dn = df.dropna(subset=["district", "neighborhood"])
    for dist_name, group in tmp_dn.groupby("district"):
        DISTRICT_TO_NEIGHBORHOODS[str(dist_name)] = sorted(
            set(str(x) for x in group["neighborhood"].unique())
        )

    cities = sorted(CITY_TO_DISTRICTS.keys())
    subtypes = sorted(df["sub_type"].dropna().astype(str).unique().tolist())
    rooms = sorted(df["room_count"].dropna().astype(str).unique().tolist())
    heating = sorted(df["heating_type"].dropna().astype(str).unique().tolist())
    listing_types = ["Продажа", "Аренда", "Аренда на день"]

    ages = sorted(
        df["building_age"].dropna().astype(str).unique().tolist(),
        key=lambda x: convert_age(x) if pd.notna(convert_age(x)) else 999,
    )
    floors = sorted(
        df["total_floor_count"].dropna().astype(str).unique().tolist(),
        key=lambda x: convert_floor_count(x) if pd.notna(convert_floor_count(x)) else 999,
    )
    floor_nos = sorted(
        df["floor_no"].dropna().astype(str).unique().tolist(),
        key=lambda x: convert_floor(x) if pd.notna(convert_floor(x)) else 999,
    )
else:
    CITY_TO_DISTRICTS = {"Стамбул": ["Kartal"]}
    DISTRICT_TO_NEIGHBORHOODS = {"Kartal": ["Kordonboyu"]}
    cities = ["Стамбул"]
    subtypes = list(SUBTYPE_MAP.keys())
    rooms = ["1+1", "2+1", "3+1", "4+1"]
    heating = list(HEATING_MAP.keys())
    listing_types = list(LISTING_MAP.keys())
    ages = list(AGE_MAP.keys())
    floors = ["1", "2", "3", "4", "5", "20 и более"]
    floor_nos = ["1", "2", "3", "4", "5", "Высокий первый этаж", "Последний этаж"]


# =========================================================
# Sidebar
# =========================================================
st.sidebar.title("🏠 Навигация")
page = st.sidebar.radio(
    "Раздел",
    ["📊 Прогноз", "📈 Дашборд", "🔍 Важность признаков", "ℹ️ Справка"],
)
st.sidebar.markdown("---")

if model is not None:
    st.sidebar.success("✅ " + MODEL_NAME + " загружен")
else:
    st.sidebar.error("❌ best_model_pipeline.pkl не найден")

if df is not None:
    st.sidebar.success("✅ Датасет: " + format(len(df), ",") + " строк")
else:
    st.sidebar.warning("⚠️ CSV не найден рядом с app.py")


# =========================================================
# СТРАНИЦА 1: Прогноз
# =========================================================
if page == "📊 Прогноз":
    st.title("🏠 Прогноз стоимости недвижимости")
    st.caption("Датасет real_estate_data.csv • модель: " + MODEL_NAME)

    if model is None:
        st.error("Положите best_model_pipeline.pkl в ту же папку, что и app.py")
        st.stop()

    with st.form("prediction_form"):
        st.subheader("📍 Локация")
        c1, c2, c3 = st.columns(3)
        default_city_index = cities.index("Стамбул") if "Стамбул" in cities else 0
        city = c1.selectbox("Город", cities, index=default_city_index)

        districts_in_city = CITY_TO_DISTRICTS.get(city, ["Unknown"])
        district = c2.selectbox("Район", districts_in_city)

        neighborhoods_in_district = DISTRICT_TO_NEIGHBORHOODS.get(district, ["Unknown"])
        neighborhood = c3.selectbox("Микрорайон", neighborhoods_in_district)

        st.subheader("🏢 Тип объекта")
        c4, c5, c6 = st.columns(3)
        default_listing_index = listing_types.index("Продажа") if "Продажа" in listing_types else 0
        listing_type = c4.selectbox("Тип объявления", listing_types, index=default_listing_index)

        default_subtype_index = subtypes.index("Квартира") if "Квартира" in subtypes else 0
        sub_type = c5.selectbox("Тип недвижимости", subtypes, index=default_subtype_index)

        heating_type = c6.selectbox("Отопление", heating)

        st.subheader("📐 Параметры")
        c7, c8 = st.columns(2)
        size = c7.number_input(
            "Площадь, м²",
            min_value=1.0,
            max_value=5000.0,
            value=100.0,
            step=1.0,
        )
        default_room_index = rooms.index("2+1") if "2+1" in rooms else 0
        room_count = c8.selectbox("Количество комнат", rooms, index=default_room_index)

        st.subheader("🏗 Здание")
        c9, c10, c11 = st.columns(3)
        building_age = c9.selectbox("Возраст здания", ages)
        total_floor_count = c10.selectbox("Этажность здания", floors)
        floor_no = c11.selectbox("Этаж объекта", floor_nos)

        submitted = st.form_submit_button(
            "💡 Рассчитать стоимость",
            use_container_width=True,
            type="primary",
        )

    if submitted:
        floor_value = convert_floor(floor_no)
        total_value = convert_floor_count(total_floor_count)

        if (
            pd.notna(floor_value)
            and pd.notna(total_value)
            and total_value > 0
            and floor_value > total_value
        ):
            st.warning("⚠️ Этаж объекта не может быть выше этажности здания.")
        else:
            try:
                x = make_input(
                    city,
                    district,
                    neighborhood,
                    listing_type,
                    sub_type,
                    room_count,
                    heating_type,
                    size,
                    building_age,
                    total_floor_count,
                    floor_no,
                )
                price, low, high = predict_price(x)

                st.markdown("---")
                a, b, c = st.columns([1, 2, 1])
                with b:
                    st.success("### 💰 Результат")
                    st.metric("Оценочная стоимость", format(price, ",.0f") + " TRY")
                    st.info(
                        "**Доверительный интервал (±MAE):** "
                        + format(low, ",.0f")
                        + " — "
                        + format(high, ",.0f")
                        + " TRY"
                    )
                    st.caption(
                        "Прогноз рассчитан моделью "
                        + MODEL_NAME
                        + ". Интервал соответствует test MAE = "
                        + str(TEST_MAE_LOG)
                        + " в log-шкале."
                    )

                with st.expander("🔎 Данные, переданные модели"):
                    st.dataframe(
                        x.T.rename(columns={0: "Значение"}),
                        use_container_width=True,
                    )
            except Exception as e:
                st.error("Не удалось выполнить прогноз.")
                st.code(str(e))
                st.info(
                    "Если появляется ошибка _fill_dtype — установите ту же "
                    "версию scikit-learn, на которой сохранялась модель."
                )


# =========================================================
# СТРАНИЦА 2: Дашборд
# =========================================================
elif page == "📈 Дашборд":
    st.title("📈 Дашборд датасета")
    if df is None:
        st.error("Файл real_estate_data.csv не найден.")
        st.stop()

    d = df.dropna(subset=["price", "size"]).copy()
    d = d[(d["price"] > 0) & (d["size"] > 0)]

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Объектов", format(len(d), ","))
    c2.metric("Признаков", len(d.columns))
    c3.metric("Городов", d["city"].nunique())
    c4.metric("Медианная цена", format(d["price"].median(), ",.0f") + " TRY")
    c5.metric("Медианная площадь", format(d["size"].median(), ",.0f") + " м²")

    st.markdown("---")

    st.subheader("🎛 Фильтры")
    f1, f2, f3 = st.columns(3)
    cities_selected = f1.multiselect(
        "Города",
        sorted(d["city"].dropna().unique().tolist()),
        default=sorted(d["city"].value_counts().head(5).index.tolist()),
    )
    listing_selected = f2.multiselect(
        "Тип сделки",
        sorted(d["listing_type"].dropna().unique().tolist()),
        default=sorted(d["listing_type"].dropna().unique().tolist()),
    )
    price_q = f3.slider(
        "Перцентиль цены (верхняя граница)",
        min_value=50,
        max_value=100,
        value=95,
        step=1,
    )

    d_filt = d.copy()
    if cities_selected:
        d_filt = d_filt[d_filt["city"].isin(cities_selected)]
    if listing_selected:
        d_filt = d_filt[d_filt["listing_type"].isin(listing_selected)]

    price_cap = d_filt["price"].quantile(price_q / 100)
    d_filt = d_filt[d_filt["price"] <= price_cap]

    st.caption(
        "После фильтрации: **"
        + format(len(d_filt), ",")
        + "** объектов, верхняя граница цены = "
        + format(price_cap, ",.0f")
        + " TRY"
    )
    st.markdown("---")

    tab1, tab2, tab3, tab4, tab5 = st.tabs(
        [
            "📊 Распределения",
            "📍 География",
            "🏠 Типы и площади",
            "🔗 Корреляции",
            "🆚 Сравнение моделей",
        ]
    )

    with tab1:
        col1, col2 = st.columns(2)
        with col1:
            fig = px.histogram(
                d_filt,
                x="price",
                nbins=60,
                log_y=True,
                title="Распределение цены (log-y)",
            )
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            log_prices = np.log1p(d_filt["price"])
            fig = px.histogram(
                log_prices,
                nbins=60,
                title="Распределение log(1+price)",
            )
            fig.update_layout(xaxis_title="log(1+price)")
            st.plotly_chart(fig, use_container_width=True)

        fig = px.histogram(
            d_filt,
            x="size",
            nbins=60,
            title="Распределение площади",
            range_x=[0, d_filt["size"].quantile(0.99)],
        )
        st.plotly_chart(fig, use_container_width=True)

    with tab2:
        top_cities = d_filt["city"].value_counts().head(15).reset_index()
        top_cities.columns = ["city", "count"]

        col1, col2 = st.columns(2)
        with col1:
            fig = px.bar(
                top_cities,
                x="count",
                y="city",
                orientation="h",
                title="Топ-15 городов по количеству объявлений",
            )
            fig.update_layout(yaxis={"categoryorder": "total ascending"})
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            mean_price = (
                d_filt.groupby("city", as_index=False)["price"]
                .mean()
                .nlargest(15, "price")
            )
            fig = px.bar(
                mean_price,
                x="price",
                y="city",
                orientation="h",
                title="Топ-15 городов по средней цене",
            )
            fig.update_layout(yaxis={"categoryorder": "total ascending"})
            st.plotly_chart(fig, use_container_width=True)

        top_districts = (
            d_filt.groupby(["city", "district"], as_index=False)
            .agg(count=("price", "size"), mean_price=("price", "mean"))
            .query("count >= 50")
            .nlargest(15, "mean_price")
        )
        top_districts["label"] = top_districts["city"] + " / " + top_districts["district"]
        fig = px.bar(
            top_districts,
            x="mean_price",
            y="label",
            orientation="h",
            title="Топ-15 районов по средней цене (не менее 50 объявлений)",
        )
        fig.update_layout(yaxis={"categoryorder": "total ascending"})
        st.plotly_chart(fig, use_container_width=True)

    with tab3:
        col1, col2 = st.columns(2)
        with col1:
            fig = px.box(
                d_filt,
                x="listing_type",
                y="price",
                log_y=True,
                title="Цена по типу сделки (log-y)",
            )
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            fig = px.violin(
                d_filt,
                x="listing_type",
                y="price",
                log_y=True,
                box=True,
                title="Плотность цены по типу сделки",
            )
            st.plotly_chart(fig, use_container_width=True)

        sample = d_filt.sample(min(4000, len(d_filt)), random_state=42)
        fig = px.scatter(
            sample,
            x="size",
            y="price",
            color="listing_type",
            log_x=True,
            log_y=True,
            opacity=0.4,
            title="Зависимость цены от площади",
        )
        st.plotly_chart(fig, use_container_width=True)

    with tab4:
        numeric_cols = [
            "price",
            "size",
            "building_age",
            "total_floor_count",
            "floor_no",
            "tom",
        ]
        numeric_cols = [c for c in numeric_cols if c in d_filt.columns]
        corr = d_filt[numeric_cols].apply(pd.to_numeric, errors="coerce").corr()

        fig = px.imshow(
            corr,
            text_auto=".2f",
            aspect="auto",
            color_continuous_scale="RdBu_r",
            zmin=-1,
            zmax=1,
            title="Корреляционная матрица числовых признаков",
        )
        st.plotly_chart(fig, use_container_width=True)

    with tab5:
        st.subheader("🆚 Сравнение моделей на validation")
        comparison = pd.DataFrame(
            {
                "Модель": ["RandomForest", "DecisionTree", "Ridge"],
                "MAE_log": [0.2810, 0.2805, 0.3117],
                "RMSE_log": [0.4551, 0.4663, 0.5132],
                "R2_log": [0.9691, 0.9676, 0.9607],
                "MAE_TRY": [157384, 160997, 170611],
                "MAPE_percent": [1507.6, 1648.1, 791.7],
            }
        )
        st.dataframe(comparison, use_container_width=True)

        col1, col2 = st.columns(2)
        with col1:
            fig = px.bar(
                comparison,
                x="Модель",
                y="MAE_log",
                title="MAE (log) — меньше = лучше",
                color="Модель",
            )
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            fig = px.bar(
                comparison,
                x="Модель",
                y="R2_log",
                title="R² (log) — больше = лучше",
                color="Модель",
            )
            st.plotly_chart(fig, use_container_width=True)

        st.success(
            "🏆 **Финальная модель: "
            + MODEL_NAME
            + "** — выбрана по минимальному MAE на validation-выборке."
        )


# =========================================================
# СТРАНИЦА 3: Важность признаков
# =========================================================
elif page == "🔍 Важность признаков":
    st.title("🔍 Важность признаков финальной модели")

    if model is None:
        st.error("Модель не загружена.")
        st.stop()

    try:
        rf = model.named_steps["model"]
        importances = rf.feature_importances_
        preprocessor = model.named_steps["preprocessor"]
        feature_names = preprocessor.get_feature_names_out()

        imp_df = pd.DataFrame(
            {"feature": feature_names, "importance": importances}
        ).sort_values("importance", ascending=False).head(25)

        fig = px.bar(
            imp_df,
            x="importance",
            y="feature",
            orientation="h",
            title="Топ-25 признаков по важности (Random Forest)",
        )
        fig.update_layout(yaxis={"categoryorder": "total ascending"})
        st.plotly_chart(fig, use_container_width=True)

        with st.expander("📋 Полная таблица важностей (топ-100)"):
            full_imp = pd.DataFrame(
                {"feature": feature_names, "importance": importances}
            ).sort_values("importance", ascending=False).head(100)
            st.dataframe(full_imp, use_container_width=True)

        st.info(
            "💡 Если какой-то параметр в форме прогноза **не меняет результат** — "
            "скорее всего, его важность близка к нулю (например, из-за высокой "
            "кардинальности и схлопывания в infrequent_sklearn)."
        )
    except Exception as e:
        st.warning("Не удалось извлечь важности: " + str(e))


# =========================================================
# СТРАНИЦА 4: Справка
# =========================================================
else:
    st.title("ℹ️ Справка")

    st.markdown("### 📦 Датасет")
    st.markdown(
        "`real_estate_data.csv` содержит **403 487 объявлений** о недвижимости "
        "в Турции (платформа Zingat.com, 2018–2019 гг.)."
    )

    st.markdown("### 🤖 Модель")
    st.markdown(
        "Используется сохранённый `best_model_pipeline.pkl` — полный `Pipeline`, "
        "включающий `ColumnTransformer` (импутация + `RobustScaler` + `OneHotEncoder`) "
        "и **" + MODEL_NAME + "**."
    )
    st.markdown("Модель принимает **" + str(len(MODEL_FEATURES)) + " признаков**:")
    st.markdown("- категориальные: " + ", ".join(CATEGORICAL_FEATURES))
    st.markdown("- числовые: " + ", ".join(NUMERIC_FEATURES))

    st.markdown("### 📊 Качество модели (на test)")
    metrics_df = pd.DataFrame(
        {
            "Метрика": ["MAE (log)", "RMSE (log)", "R² (log)", "MAE (TRY)", "MAPE"],
            "Значение": ["0.2813", "0.4583", "0.9687", "~176 706", "181.7 %"],
        }
    )
    st.dataframe(metrics_df, use_container_width=True)

    st.markdown(
        "**Доверительный интервал** в приложении рассчитан как "
        "`expm1(log_pred ± MAE_log)` и соответствует ошибке в лог-шкале."
    )

    st.markdown("### ⚠️ Ограничения модели")
    st.markdown("1. **Гетероскедастичность остатков** — разброс ошибок растёт с ценой.")
    st.markdown("2. **Недооценка элитной недвижимости** (> 1 млн TRY).")
    st.markdown("3. **Высокий MAPE** для дешёвых объектов (следствие лог-преобразования).")
    st.markdown("4. **Не учитываются** временные факторы, координаты, состояние ремонта.")
    st.markdown(
        "5. **district и neighborhood** схлопнуты из-за `min_frequency=20` в "
        "`OneHotEncoder` — реальная важность этих признаков в модели может быть занижена."
    )

    st.markdown("### 🔄 Преобразование категорий")
    st.markdown(
        "CSV и модель используют **разные представления** категорий: "
        "CSV — русские названия, модель обучалась на исходных **турецких**. "
        "Приложение выполняет преобразование перед `predict`."
    )
    st.markdown(
        "Признак `listing_type` передан в модель как **число** "
        "(LabelEncoder: `Аренда=0, Аренда на день=1, Продажа=2`)."
    )

    st.markdown("### 📁 Файлы проекта")
    st.code(
        "📂 project/\n"
        " ├─ app.py                    ← это приложение\n"
        " ├─ best_model_pipeline.pkl   ← обученная модель\n"
        " ├─ feature_schema.pkl        ← схема признаков\n"
        " └─ real_estate_data.csv      ← данные для дашборда",
        language="text",
    )

    st.markdown("### 👥 Авторы")
    st.markdown("Тимур Еникеев и Гареев Рустам, 2026.")


# =========================================================
# Футер
# =========================================================
st.sidebar.markdown("---")
st.sidebar.caption("🎓 Учебный проект • 2026")